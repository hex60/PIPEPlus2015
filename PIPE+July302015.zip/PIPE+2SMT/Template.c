void testHLPNJune18(Z3_context ctx){
	 LOG_MSG("Test a high level Petri net using set:\n");
	 printf("\nTest a high level Petri net using set:\n");

		//declaration for state tuple sort;
		Z3_func_decl nil_decl, is_nil_decl, cons_decl, is_cons_decl, head_decl, tail_decl, mk_tuple_decl;
		Z3_sort intsort = Z3_mk_int_sort(ctx);
		Z3_symbol names[] = {Z3_mk_string_symbol(ctx, "P1"),
				Z3_mk_string_symbol(ctx, "P2")};
		Z3_sort sorts[] = {Z3_mk_set_sort(ctx, intsort),
				Z3_mk_set_sort(ctx, intsort)};
		Z3_func_decl proj_decls[2];
		Z3_sort STATE_TUPLE = Z3_mk_tuple_sort(ctx, Z3_mk_string_symbol(ctx, "State"),
				2, names, sorts, & mk_tuple_decl, proj_decls);
		//initial state: s0
		Z3_ast S0 = Z3_mk_const(ctx, Z3_mk_string_symbol(ctx, "S0"), STATE_TUPLE);
		Z3_ast projS0P0 = mk_unary_app(ctx, proj_decls[0], S0);
		Z3_ast projS0P1 = mk_unary_app(ctx, proj_decls[1], S0);

				Z3_ast set0 = Z3_mk_empty_set(ctx, intsort);
		Z3_ast set1 = Z3_mk_empty_set(ctx, intsort);
				Z3_ast set00 = Z3_mk_set_add(ctx, set0, mk_int(ctx, 1));
		Z3_ast set000 = Z3_mk_set_add(ctx, set00, mk_int(ctx, 2));
				Z3_ast constr_ini[2] = {Z3_mk_eq(ctx, projS0P0, set000), Z3_mk_eq(ctx, projS0P1, set1)};
				Z3_ast and_S0 = Z3_mk_and(ctx, 2, constr_ini);
		Z3_assert_cnstr(ctx, and_S0); //initial condition(head(states))

		//transition: if(p1>0)p2=p1
		Z3_ast S1 = Z3_mk_const(ctx, Z3_mk_string_symbol(ctx, "S1"), STATE_TUPLE);
		Z3_ast projS1P0 = mk_unary_app(ctx, proj_decls[0], S1);
		Z3_ast projS1P1 = mk_unary_app(ctx, proj_decls[1], S1);
		Z3_ast x0 = Z3_mk_const(ctx, Z3_mk_string_symbol(ctx, "x0"), intsort);//int sort may be structured data
//		Z3_ast x0p = Z3_mk_const(ctx, Z3_mk_string_symbol(ctx, "x0p"), intsort); //the result token is x0p
				Z3_ast t0_if_cond_and[] = {Z3_mk_set_member(ctx, x0, projS0P0), Z3_mk_gt(ctx, x0, mk_int(ctx, 0))};
		Z3_ast t0_if_cond = Z3_mk_and(ctx, 2, t0_if_cond_and);
				Z3_ast t0_and_true[] = {Z3_mk_eq(ctx, projS1P0, Z3_mk_set_del(ctx, projS0P0, x0)),
										Z3_mk_eq(ctx, projS1P1, Z3_mk_set_add(ctx, projS0P1, x0))};
		Z3_ast t0_if_true = Z3_mk_and(ctx, 2, t0_and_true);
				Z3_ast t0_and_false[] = {Z3_mk_eq(ctx, projS1P0, projS0P0),
										Z3_mk_eq(ctx, projS1P1, projS0P1)};
		Z3_ast t0_if_false = Z3_mk_and(ctx, 2, t0_and_false);
		Z3_ast tran0 = Z3_mk_ite(ctx, t0_if_cond, t0_if_true, t0_if_false);
		Z3_assert_cnstr(ctx, tran0);

		//error condition p1 = 2;
		Z3_ast err_cond = Z3_mk_set_member(ctx, mk_int(ctx, 0), projS1P1);
		Z3_assert_cnstr(ctx, err_cond);
 }
