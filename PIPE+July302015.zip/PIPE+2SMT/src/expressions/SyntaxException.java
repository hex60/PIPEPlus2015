/*
 * SyntaxException.java
 *
 * Created on 17 / agost / 2007, 12:28
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package expressions;

/**
 *
 * @author marc
 */
public class SyntaxException extends Exception {
    
    /** Creates a new instance of SyntaxException */
    public SyntaxException() {
    }
    
}
