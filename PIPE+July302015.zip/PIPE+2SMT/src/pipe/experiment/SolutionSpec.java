/*
 * SolutionSpec.java
 *
 * Created on 24 / juliol / 2007, 13:06
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package pipe.experiment;
import java.util.Vector;

/**
 *
 * @author marc
 */
public class SolutionSpec {
    
    /** Creates a new instance of SolutionSpec */
    public SolutionSpec() {
    }
    
    
}
