package pipe.dataLayer.calculations;

public class EnterOptionsException extends Exception {
   
   public EnterOptionsException() {
      super();
   }
   
}
