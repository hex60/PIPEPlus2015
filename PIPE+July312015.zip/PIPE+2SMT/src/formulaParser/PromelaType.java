package formulaParser;

public enum PromelaType {
	pSHORT, pINT
}
