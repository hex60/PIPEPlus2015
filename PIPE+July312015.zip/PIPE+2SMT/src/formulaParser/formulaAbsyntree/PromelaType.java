package formulaParser.formulaAbsyntree;

public enum PromelaType {
	pSHORT, pINT
}
