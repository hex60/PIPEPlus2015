import pipe.gui.CreateGui;


/**
 * <b>RunGui</b> - Start-up class with main function
 * @version 1.0
 * @author Alex Duncan
 */
public class RunGui{

   
  public static void main(String args[]){
  	CreateGui.init();
  }
  
}
