/*
 * InvalidTypeException.java
 *
 * Created on 2 / agost / 2007, 11:01
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package expressions;

/**
 *
 * @author marc
 */
public class InvalidTypeException extends Exception{}
